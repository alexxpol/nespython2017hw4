#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb 12 10:07:19 2018

@author: apolyakov
"""

#%%
import re
import requests

import matplotlib.pylab as plt
import numpy as np
import pandas as pd

pd.set_option('float_format', '{:6.2f}'.format)
np.set_printoptions(precision=3, suppress=True)

url = 'https://drive.google.com/uc?export= download&id=0B6ZlG_Eygdj-c1kzcmUxN05VUXM'
path = '/Users/alenasemanina/Desktop/NES/mod3/python/data/Survey.zip'
#%%
#task_1
response = requests.get(url)
with open(path, "wb") as file:
    file.write(response.content)
#%%
zf = zipfile.ZipFile(path)
files = zf.namelist()

print(files)
#%%
#Load data into pandas DataFrame. Print datatypes.

raw_que = pd.read_csv(zf.open(files[-1]))
raw_que.columns = [x.strip() for x in raw_que.columns]

raw_answ = pd.read_csv(zf.open(files[-2]))
raw_answ.columns = [x.strip() for x in raw_answ.columns]

#%%
print('Number of questions', raw_que.iloc[1:,:].shape[0], '\nNumber of respondents', raw_answ.iloc[:,:2].shape[0] )
#%%
#task_2
Country_group = raw_answ.groupby('Country').count()
Country_group = Country_group.sort_values('Respondent', na_position = 'last', ascending = False)
print('\n\nDistribution per country\n\n',Country_group.iloc[:10,:1],'\n\n Share of each country \n\n ',Country_group.iloc[:10,:1]/raw_answ.iloc[:,:2].shape[0])

#%%
#task_3
 
url1 = 'https://en.wikipedia.org/wiki/List_of_countries_and_dependencies_by_population'

#%%
population_raw = pd.read_html(url1, header = 0)
#%%
population = population_raw[1]  #выбираем табличку с популяциями
#%%
for i in range(0,240):  #убираем () и [] из семпла
    population.iloc[i,1] = population.iloc[i,1].split('[')[0]
    population.iloc[i,1] = population.iloc[i,1].split('(')[0]
    

population = population[population.iloc[:,2]>100]
print(population.iloc[:,1:3]) 
#%%
Resp = Country_group.iloc[:,:1]   # делаем таблицу в которой индекс страны и одна колонка с количеством респондентов.
Resp = Resp[Resp['Respondent']>100]
 
Popul = population.iloc[:,1:3]
 
#%%
for i in range(0,239):
    
    if Popul['Country (or dependent territory)'][i] == 'Slovakia':
        Popul['Country (or dependent territory)'][i] = 'Slovak Republic'
    if Popul['Country (or dependent territory)'][i] == 'Russia':
        Popul['Country (or dependent territory)'][i] = 'Russian Federation'


#%%
Popul = Popul.set_index('Country (or dependent territory)')
#%%
#Popul_Resp = pd.merge(Resp, Popul, how = 'left',left_index = True,left_on = ['Country'])
Popul_Resp = pd.concat([Resp, Popul], axis=1, join_axes=[Resp.index]).dropna()
Popul_Resp['Population'] = Popul_Resp['Population'].map(lambda x: int(x))

Percent = Popul_Resp['Respondent']/Popul_Resp['Population']
Percent = Percent.map(lambda x: '%11.6f' % x)
Percent = Percent.sort_values(na_position = 'last', ascending = False)

print(Percent[:10])
#%%
#task_4
Version_group = raw_answ.groupby('VersionControl').count()
Version_group = Version_group.sort_values('Respondent', na_position = 'last', ascending = False)
Version_group = Version_group['Respondent']

#%%
#task_5
languages = {}
raw_answ['HaveWorkedLanguage'].dropna()

for i in range(0,51392):
    for element in str(raw_answ['HaveWorkedLanguage'].iloc[i]).split(';')[:]:
        if element != 'nan':
            languages[element.replace(' ', '')] = element.replace(' ', '')
            
#%%
#task_5
raw_answ['HaveWorkedLanguage'].dropna().str.split(';', expand = True).stack().unique()
         
#%%
#task_6
count = {}

for i in range(0,51392):
    for element in str(raw_answ['HaveWorkedLanguage'].iloc[i]).split(';')[:]:
        if element.replace(' ', '') in languages:
            count[element.replace(' ', '')] =  0
            
for i in range(0,51392):
    for element in str(raw_answ['HaveWorkedLanguage'].iloc[i]).split(';')[:]:
        if element.replace(' ', '') in languages:
            count[element.replace(' ', '')] +=  1
            
#%%
#task_6
raw_answ['HaveWorkedLanguage'].dropna().str.split(';', expand = True).stack().value_counts()[:10]

#%%
data = raw_answ.copy()
for j in raw_answ:
    for i in languages:
        if i in raw_answ['HaveWorkedLanguage'].iloc[1].split(';')[:]:
            data[i] = 1
        else:
            data[i] = 0

lang_group = data.groupby('Country').count()


for i in languages:
    lang_group = lang_group.sort_values(i, na_position = 'last', ascending = False)






















